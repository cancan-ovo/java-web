package com.zcx.studentManagement.servlet;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.zcx.studentManagement.dao.AdminDao;
import com.zcx.studentManagement.entity.Administrator;
import com.zcx.studentManagement.entity.BaseResponse;
import com.zcx.studentManagement.utils.RequestUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(urlPatterns = "/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String jsonLogin = RequestUtil.getRequestBody(req);
        JsonObject jsonObject = JsonParser.parseString(jsonLogin).getAsJsonObject();
        String username = jsonObject.get("username").getAsString();
        String password = jsonObject.get("password").getAsString();
        String vscode = jsonObject.get("vscode").getAsString().toUpperCase();
        String trueVsCode = ((String) req.getSession().getAttribute("validateCode")).toUpperCase();
        BaseResponse<Integer> baseResponse = new BaseResponse<>();
        if (vscode.equals(trueVsCode)){
            List<Administrator> administrators = AdminDao.getAdministratorByName(username);
            if (!administrators.isEmpty()) {
                for (int i = 0; i < administrators.size(); i++){
                    if (password.equals(administrators.get(i).getPassword())) {
                        baseResponse.setCode(200);
                        baseResponse.setMsg("登陆成功");
                        HttpSession session = req.getSession();
                        session.setAttribute("username",username);
                        break;
                    }
                    if (i == administrators.size() - 1) {
                        baseResponse.setCode(500);
                        baseResponse.setMsg("密码错误");
                    }
                }
            }else {
                baseResponse.setCode(400);
                baseResponse.setMsg("用户名不存在");
            }
        }else {
            baseResponse.setCode(300);
            baseResponse.setMsg("验证码错误");
        }
        Gson gson = new Gson();
        PrintWriter out = resp.getWriter();
        out.print(gson.toJson(baseResponse));
        out.flush();
        out.close();
    }
}
