package com.zcx.studentManagement.servlet.StudentServlet;

import com.google.gson.Gson;
import com.zcx.studentManagement.dao.ClazzDao;
import com.zcx.studentManagement.dao.StudentDao;
import com.zcx.studentManagement.entity.BaseResponse;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(urlPatterns = "/delStudent")
public class StudentDelServlet extends HttpServlet {    //删除学生

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        String studentName = req.getParameter("studentName");
        BaseResponse<Integer> response = new BaseResponse<>();
            int rows = StudentDao.delStudentById(id);
            if (rows > 0) {
                response.setCode(200);
                response.setMsg("删除成功");
            }else {
                response.setCode(600);
                response.setMsg("删除失败");
            }
        Gson gson = new Gson();
        String json = gson.toJson(response);
        PrintWriter out = resp.getWriter();
        out.write(json);
        out.flush();
        out.close();
    }
}
