package com.zcx.studentManagement.servlet.TeacherServlet;

import com.google.gson.Gson;

import com.mysql.cj.util.StringUtils;
import com.zcx.studentManagement.dao.ClazzDao;
import com.zcx.studentManagement.dao.TeacherDao;
import com.zcx.studentManagement.entity.BaseResponse;
import com.zcx.studentManagement.entity.Clazz;
import com.zcx.studentManagement.entity.Teacher;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@WebServlet(urlPatterns = "/searchTeachers")
public class TeachersSearchServlet extends HttpServlet {    //模糊查询老师
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int page = Integer.parseInt(req.getParameter("page"));
        int limit = Integer.parseInt(req.getParameter("limit"));
        String info = req.getParameter("info");
        List<Teacher> teachers = TeacherDao.searchTeachers(info, page, limit);
        BaseResponse<List<Teacher>> response = new BaseResponse<>();
        response.setCode(200);
        response.setMsg("查询得到的信息");
        response.setData(teachers);
        response.setCount(TeacherDao.getSearchCount(info));
        Gson gson = new Gson();
        String json = gson.toJson(response);
        PrintWriter out = resp.getWriter();
        out.write(json);
        out.flush();
        out.close();
    }
}
