package com.zcx.studentManagement.dao;

import com.zcx.studentManagement.entity.Clazz;
import com.zcx.studentManagement.utils.DruidUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class ClazzDao {

    private static Clazz getClazz(ResultSet resultSet) { //通过查询结果获取一个班级对象
        Clazz clazz = new Clazz();
        try {
            int clazzId = resultSet.getInt("clazz_id");
            String clazzName = resultSet.getString("clazz_name");
            String clazzInformation = resultSet.getString("clazz_information");
            clazz.setId(clazzId);
            clazz.setName(clazzName);
            clazz.setInformation(clazzInformation);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return clazz;
    }

    public static List<Clazz> getClazzs(int page, int limit) {  //获取班级分页信息
        List<Clazz> clazzs = new ArrayList<Clazz>();
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareCall("select * from clazz limit ?, ?");
            statement.setInt(1, (page - 1) * limit);
            statement.setInt(2, limit);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Clazz clazz = getClazz(resultSet);
                clazzs.add(clazz);
            }
            DruidUtil.close(resultSet, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return clazzs;
    }

    public static int getCount() {   //获取班级数量
        int count = 0;
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareCall("select count(1) from clazz");
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                count = resultSet.getInt(1);
            }
            DruidUtil.close(resultSet, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }
    public static int delClazzById(int id) { //通过id删除班级
        int rows = 0;
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareCall("delete from clazz where clazz_id = ?");
            statement.setInt(1, id);
            rows = statement.executeUpdate();
            DruidUtil.close(null, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rows;
    }

    public static int updateClazz(Clazz clazz) { //通过id更新班级
        int rows = 0;
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareCall(
                    "update clazz set clazz_name = ?, clazz_information = ? where clazz_id = ?");
            statement.setString(1, clazz.getName());
            statement.setString(2, clazz.getInformation());
            statement.setInt(3, clazz.getId());
            rows = statement.executeUpdate();
            DruidUtil.close(null, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rows;
    }

    public static Clazz getClazzById(int id) {   //通过班级id返回班级对象
        Clazz clazz = new Clazz();
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareStatement("select * from clazz where clazz_id = ?");
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                clazz = getClazz(resultSet);
            }
            DruidUtil.close(resultSet, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return clazz;
    }

    public static int addClazz(Clazz clazz) {    //添加班级
        int rows = 0;
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareStatement(
                    "insert into clazz (clazz_name, clazz_information) values (?,?)");
            statement.setString(1, clazz.getName());
            statement.setString(2, clazz.getInformation());
            rows = statement.executeUpdate();
            DruidUtil.close(null, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rows;
    }

    public static int delClazzs(HashSet<Integer> idSet) {    //批量删除班级
        int rows = 0;
        if (null == idSet || idSet.isEmpty())
            return rows;
        try {
            Connection connection = DruidUtil.getConnection();
            StringBuilder sql = new StringBuilder("delete from clazz where clazz_id in (");
            for (Integer id : idSet) {
                sql.append(id).append(",");
            }
            sql.deleteCharAt(sql.length() - 1).append(")");
            PreparedStatement statement = connection.prepareStatement(sql.toString());
            rows = statement.executeUpdate();
            DruidUtil.close(null, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rows;
    }

    public static List<Clazz> searchClazzs(String info, int page, int limit) {   //根据信息模糊查询班级
        info = "%" + info + "%";
        List<Clazz> clazzList = new ArrayList<>();
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareStatement(
                    "select * from clazz where clazz_id like ? or clazz_name like ? or clazz_information like ? limit ?, ?");
            statement.setString(1, info);
            statement.setString(2, info);
            statement.setString(3, info);
            statement.setInt(4, (page - 1) * limit);
            statement.setInt(5, limit);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Clazz clazz = getClazz(resultSet);
                clazzList.add(clazz);
            }
            DruidUtil.close(resultSet, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return clazzList;
    }

    public static List<Clazz> getAllClazzs() {  //获取全体班级
        List<Clazz> clazzs = new ArrayList<>();
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareStatement("select * from clazz");
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Clazz clazz = getClazz(resultSet);
                clazzs.add(clazz);
            }
            DruidUtil.close(resultSet, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return clazzs;
    }

    public static int getSearchCount(String info) {  //获取查找到的班级数量
        info = "%" + info + "%";
        int count = 0;
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareStatement("select count(1) from clazz where clazz_id like ? or clazz_name like ? or clazz_information like ?");
            statement.setString(1, info);
            statement.setString(2, info);
            statement.setString(3, info);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                count = resultSet.getInt(1);
            }
            DruidUtil.close(resultSet, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }



    public static int findByClazzName(String clazzName) {
        int row = 0;
        Connection conn = DruidUtil.getConnection();
        try {
            CallableStatement statement = conn.prepareCall(
                    "call { (SELECT count(1) FROM clazz WHERE clazz_name = ?) }");
            statement.setString(1, clazzName);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                row = resultSet.getInt(1);
            }
            DruidUtil.close(resultSet, statement, conn);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return row;
    }
}
