package com.zcx.studentManagement.dao;

import com.zcx.studentManagement.entity.Clazz;
import com.zcx.studentManagement.entity.Teacher;
import com.zcx.studentManagement.utils.DruidUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class TeacherDao {

    private static Teacher getTeacher(ResultSet resultSet) { //根据查询结果返回老师对象
        Teacher teacher = new Teacher();
        try {
            int teacherId = resultSet.getInt("teacher_id");
            String teacherName = resultSet.getString("teacher_name");
            String teacherSex = resultSet.getString("teacher_sex");
            String teacherMobile = resultSet.getString("teacher_mobile");
            String teacherEmail = resultSet.getString("teacher_email");
            teacher.setId(teacherId);
            teacher.setName(teacherName);
            teacher.setSex(teacherSex);
            teacher.setMobile(teacherMobile);
            teacher.setEmail(teacherEmail);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return teacher;
    }

    public static List<Teacher> getTeachers(int page, int limit) {  //返回老师列表
        List<Teacher> teachers = new ArrayList<>();
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareStatement(
                    "select * from teacher limit ?, ?");
            statement.setInt(1, (page - 1) * limit);
            statement.setInt(2, limit);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Teacher teacher = getTeacher(resultSet);
                teachers.add(teacher);
            }
            DruidUtil.close(resultSet, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return teachers;
    }

    public static int getCount() {   //返回全体老师数量
        int count = 0;
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareCall(
                    "select count(1) from teacher");
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                count = resultSet.getInt(1);
            }
            DruidUtil.close(resultSet, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }

    public static int delTeacherById(int id) {   //通过id删除老师
        int rows = 0;
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareCall(
                    "delete from teacher where teacher_id = ?");
            statement.setInt(1, id);
            rows = statement.executeUpdate();
            DruidUtil.close(null, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rows;
    }

    public static int updateTeacher(Teacher teacher) {   //更新老师
        int rows = 0;
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareCall(
                    "update teacher set teacher_name = ?, teacher_sex = ? " +
                            ", teacher_mobile = ? , teacher_email = ? where teacher_id = ?");
            statement.setString(1, teacher.getName());
            statement.setString(2, teacher.getSex());
            statement.setString(3, teacher.getMobile());
            statement.setString(3, teacher.getEmail());
            statement.setInt(4, teacher.getId());
            rows = statement.executeUpdate();
            DruidUtil.close(null, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rows;
    }

    public static Teacher getTeacherById(int id) {   //通过id获取老师
        Teacher teacher = new Teacher();
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareStatement("select * from teacher where teacher_id = ?");
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                teacher = getTeacher(resultSet);
            }
            DruidUtil.close(resultSet, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return teacher;
    }

    public static int addTeacher(Teacher teacher) {  //添加老师
        int rows = 0;
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareStatement(
                    "insert into teacher (teacher_name, teacher_sex ,teacher_mobile , teacher_email) values (?,?,?,?)");
            statement.setString(1, teacher.getName());
            statement.setString(2, teacher.getSex());
            statement.setString(3, teacher.getMobile());
            statement.setString(4, teacher.getEmail());
            rows = statement.executeUpdate();
            DruidUtil.close(null, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rows;
    }

    public static int delTeachers(HashSet<Integer> idSet) {  //批量删除老师
        int rows = 0;
        if (null == idSet || idSet.isEmpty())
            return rows;
        try {
            Connection connection = DruidUtil.getConnection();
            StringBuilder sql = new StringBuilder("delete from clazz where clazz_id in (");
            for (Integer id : idSet) {
                sql.append(id).append(",");
            }
            sql.deleteCharAt(sql.length() - 1).append(")");
            PreparedStatement statement = connection.prepareStatement(sql.toString());
            rows = statement.executeUpdate();
            DruidUtil.close(null, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rows;
    }

    public static List<Teacher> searchTeachers(String info, int page, int limit) {   //模糊查找老师
        info = "%" + info + "%";
        List<Teacher> teachersList = new ArrayList<>();
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareStatement(
                    "select * from teacher where teacher_id like ? or teacher_name like ?  or teacher_sex like ?or teacher_mobile like ? or teacher_email like ? limit ?, ?");
            statement.setString(1, info);
            statement.setString(2, info);
            statement.setString(3, info);
            statement.setString(4, info);
            statement.setString(5, info);
            statement.setInt(6, (page - 1) * limit);
            statement.setInt(7, limit);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Teacher teacher = getTeacher(resultSet);
                teachersList.add(teacher);
            }
            DruidUtil.close(resultSet, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return teachersList;
    }

    public static List<Teacher> getAllTeachers() {  //获取所有老师
        List<Teacher> teachers = new ArrayList<>();
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareStatement("select * from teacher");
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Teacher teacher = getTeacher(resultSet);
                teachers.add(teacher);
            }
            DruidUtil.close(resultSet, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return teachers;
    }

    public static int getSearchCount(String info) {  //获取查找出的老师数量
        info = "%" + info + "%";
        int count = 0;
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareStatement("select count(1) from teacher where teacher_id like ? or teacher_name like ? or teacher_sex like ? or teacher_mobile like ? or teacher_email like ?");
            statement.setString(1, info);
            statement.setString(2, info);
            statement.setString(3, info);
            statement.setString(4, info);
            statement.setString(5, info);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                count = resultSet.getInt(1);
            }
            DruidUtil.close(resultSet, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }



}
