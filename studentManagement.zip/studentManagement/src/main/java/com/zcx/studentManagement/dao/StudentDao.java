package com.zcx.studentManagement.dao;

import com.zcx.studentManagement.entity.Student;
import com.zcx.studentManagement.entity.Teacher;
import com.zcx.studentManagement.utils.DruidUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class StudentDao {

    private static Student getStudent(ResultSet resultSet) { //根据查询结果返回学生对象
        Student student = new Student();
        try {
            int studentId = resultSet.getInt("student_id");
            String studentName = resultSet.getString("student_name");
            String studentSex = resultSet.getString("student_sex");
            String studentBirthday = resultSet.getString("student_birthday");
            String studentMobile = resultSet.getString("student_mobile");
            String studentEmail = resultSet.getString("student_email");
            String studentClazzName = resultSet.getString("student_clazzName");
            String studentTeacherName = resultSet.getString("student_teacherName");

            student.setId(studentId);
            student.setName(studentName);
            student.setSex(studentSex);
            student.setBirthday(studentBirthday);
            student.setMobile(studentMobile);
            student.setEmail(studentEmail);
            student.setClazzName(studentClazzName);
            student.setTeacherName(studentTeacherName);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return student;
    }

    public static List<Student> getStudents(int page, int limit) {  //返回学生分页信息
        List<Student> students = new ArrayList<Student>();
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareStatement(
                    "select * from student limit ?, ?");
            statement.setInt(1, (page - 1) * limit);
            statement.setInt(2, limit);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Student student = getStudent(resultSet);
                students.add(student);
            }
            DruidUtil.close(resultSet, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }

    public static int getCount() {   //返回学生总数
        int count = 0;
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareCall(
                    "select count(1) from student");
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                count = resultSet.getInt(1);
            }
            DruidUtil.close(resultSet, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }

    public static int delStudentById(int id) {   //通过id删除学生
        int rows = 0;
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareCall(
                    "delete from student where student_id = ?");
            statement.setInt(1, id);
            rows = statement.executeUpdate();
            DruidUtil.close(null, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rows;
    }

    public static int updateStudent(Student student) {   //更新学生
        int rows = 0;
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareCall(
                    "update teacher set student_name = ?, student_sex = ? ,student_birthday = ? " +
                            ", student_mobile = ? , student_email = ? , student_clazzName = ? , student_teacherName = ?" +
                            " where student_id = ?");
            statement.setString(1, student.getName());
            statement.setString(2, student.getSex());
            statement.setString(3, student.getMobile());
            statement.setString(4, student.getEmail());
            statement.setInt(5, student.getId());
            statement.setString(6, student.getClazzName());
            statement.setString(7, student.getTeacherName());
            rows = statement.executeUpdate();
            DruidUtil.close(null, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rows;
    }

    public static Student getStudentById(int id) {   //通过id获取学生
        Student student = new Student();
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareStatement("select * from student where student_id = ?");
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                student = getStudent(resultSet);
            }
            DruidUtil.close(resultSet, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return student;
    }

    public static int addStudent(Student student) {  //添加学生
        int rows = 0;
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareStatement(
                    "insert into student (student_name, student_sex ,student_birthday, student_mobile , student_email ,student_clazzName,student_teacherName ) values (?,?,?,?,?,?,?)");
            statement.setString(1, student.getName());
            statement.setString(2, student.getSex());
            statement.setString(3, String.valueOf(student.getBirthday()));
            statement.setString(4, student.getMobile());
            statement.setString(5, student.getEmail());
            statement.setString(6, student.getClazzName());
            statement.setString(7, student.getTeacherName());

            rows = statement.executeUpdate();
            DruidUtil.close(null, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rows;
    }

    public static int delStudents(HashSet<Integer> idSet) {  //批量删除学生
        int rows = 0;
        if (null == idSet || idSet.isEmpty())
            return rows;
        try {
            Connection connection = DruidUtil.getConnection();
            StringBuilder sql = new StringBuilder("delete from student where student_id in (");
            for (Integer id : idSet) {
                sql.append(id).append(",");
            }
            sql.deleteCharAt(sql.length() - 1).append(")");
            PreparedStatement statement = connection.prepareStatement(sql.toString());
            rows = statement.executeUpdate();
            DruidUtil.close(null, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rows;
    }

    public static List<Student> searchStudents(String info, int page, int limit) {   //模糊查找学生
        info = "%" + info + "%";
        List<Student> studentsList = new ArrayList<>();
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareStatement(
                    "select * from student where student_id like ? or  student_sex like ? student_name like ?  student_birthday like ? or teacher_mobile like ? or teacher_email like ?   student_clazzName like ?  student_teacherName like ? limit ?, ?");
            statement.setString(1, info);
            statement.setString(2, info);
            statement.setString(3, info);
            statement.setString(4, info);
            statement.setString(5, info);
            statement.setString(6, info);
            statement.setString(7, info);
            statement.setInt(8, (page - 1) * limit);
            statement.setInt(9, limit);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Student student = getStudent(resultSet);
                studentsList.add(student);
            }
            DruidUtil.close(resultSet, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return studentsList;
    }

    public static int getSearchCount(String info) {  //获取查找出的学生数量
        int count = 0;
        try {
            Connection connection = DruidUtil.getConnection();
            PreparedStatement statement = connection.prepareStatement(
                    "select count(1) from student where student_id like ? or student_name like ? or student_sex like ?" +
                    "  or student_birthday like ? or teacher_mobile like ? or teacher_email like ? or student_clazzName like ? or student_teacherName like ?");
            statement.setString(1, info);
            statement.setString(2, info);
            statement.setString(3, info);
            statement.setString(4, info);
            statement.setString(5, info);
            statement.setString(6, info);
            statement.setString(7, info);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                count = resultSet.getInt(1);
            }
            DruidUtil.close(resultSet, statement, connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }

    public static int getStuByClazzName(String clazzName) {
        int row = 0;
        Connection conn = DruidUtil.getConnection();
        try {
            CallableStatement statement = conn.prepareCall("SELECT count(1) FROM student WHERE student_clazzName = ?");
            statement.setString(1, clazzName);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                row = resultSet.getInt(1);
            }
            DruidUtil.close(resultSet, statement, conn);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return row;
    }


}
